./ocr_tool  -i ./test.txt -s 32 -t ./simyou.ttf -j example.json
